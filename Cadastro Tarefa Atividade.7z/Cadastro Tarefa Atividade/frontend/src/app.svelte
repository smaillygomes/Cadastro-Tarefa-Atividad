<script>
    import axios from 'axios';
    let descricao = '';
    let tarefas = [];
  
    const carregarTarefas = async () => {
      const res = await axios.get('http://localhost:3000/tarefas');
      tarefas = res.data;
    };
  
    const adicionarTarefa = async () => {
      if (!descricao.trim()) return;
      await axios.post('http://localhost:3000/tarefas', { descricao });
      descricao = '';
      await carregarTarefas();
    };
  
    const alternarTarefa = async (id) => {
      await axios.put(`http://localhost:3000/tarefas/${id}`);
      await carregarTarefas();
    };
  
    const deletarTarefa = async (id) => {
      await axios.delete(`http://localhost:3000/tarefas/${id}`);
      await carregarTarefas();
    };
  
    carregarTarefas();
  </script>
  
  <main>
    <h2>📝Cadastro de Tarefas</h2>
    <input bind:value={descricao} placeholder="Adicionar tarefa" />
    <button on:click={adicionarTarefa}>Adicionar</button>
  
      <ul>
    {#each tarefas as tarefa}
      <li class="{tarefa.concluida ? 'concluida' : ''}">
        <span on:click={() => alternarTarefa(tarefa.id)} style="text-decoration: {tarefa.concluida ? 'line-through' : 'none'}">
          {tarefa.descricao}
        </span>
        <button on:click={() => deletarTarefa(tarefa.id)}>Excluir</button>
      </li>
    {/each}
  </ul>
</main>


  
    <style>
      main {
        padding: 2rem;
        font-family: Arial, sans-serif;
        max-width: 600px;
        margin: 0 auto;
      }
    
      h1 {
        text-align: center;
        color: #67eb6e;
      }
    
      input {
        width: calc(100% - 100px);
        padding: 0.5rem;
        font-size: 1rem;
        border: 1px solid #ccc;
        border-radius: 4px;
      }
    
      button {
        padding: 0.5rem 1rem;
        font-size: 1rem;
        color: white;
        background-color: #007bff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s ease;
        margin-left: 1rem;
      }
    
      button:hover {
        background-color: #0056b3;
      }
    
      ul {
        list-style-type: none;
        padding: 0;
      }
    
      li {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0.5rem;
        border: 1px solid #ccc;
        border-radius: 4px;
        margin-top: 0.5rem;
        background-color: #f9f9f9;
      }
    
      li.concluida {
        background-color: #e6e6e6;
        color: gray;
        font-style: italic;
        text-decoration: line-through;
      }
    
      span {
        flex: 1;
        cursor: pointer;
      }
    
      span:hover {
        text-decoration: underline;
      }
    </style>