const express = require('express');
const cors = require('cors');
const db = require('./db');

const app = express();
app.use(cors());
app.use(express.json());

// Listar tarefas
app.get('/tarefas', (req, res) => {
  console.log('Recebida requisição GET em /tarefas');
  db.query('SELECT * FROM tarefa', (err, results) => {
    if (err) {
      console.error('Erro ao listar tarefas:', err);
      return res.status(500).json({ error: 'Erro ao listar tarefas', details: err });
    }
    console.log('Tarefas listadas com sucesso:', results);
    res.json(results);
  });
});

// Criar tarefa
app.post('/tarefas', (req, res) => {
  console.log('Recebida requisição POST em /tarefas com body:', req.body);
  const { descricao } = req.body;
  if (!descricao) {
    console.warn('Tentativa de criar tarefa sem descrição');
    return res.status(400).json({ error: 'O campo "descricao" é obrigatório.' });
  }
  db.query('INSERT INTO tarefa (descricao) VALUES (?)', [descricao], (err, results) => {
    if (err) {
      console.error('Erro ao criar tarefa:', err);
      return res.status(500).json({ error: 'Erro ao criar tarefa', details: err });
    }
    console.log('Tarefa criada com sucesso:', results);
    res.status(201).send('Tarefa criada');
  });
});

// Atualizar tarefa (concluir)
app.put('/tarefas/:id', (req, res) => {
  console.log('Recebida requisição PUT em /tarefas/:id com params:', req.params);
  const { id } = req.params;
  db.query('UPDATE tarefa SET concluida = NOT concluida WHERE id = ?', [id], (err, results) => {
    if (err) {
      console.error('Erro ao atualizar tarefa:', err);
      return res.status(500).json({ error: 'Erro ao atualizar tarefa', details: err });
    }
    console.log('Tarefa atualizada com sucesso:', results);
    res.send('Tarefa atualizada');
  });
});

// Deletar tarefa
app.delete('/tarefas/:id', (req, res) => {
  console.log('Recebida requisição DELETE em /tarefas/:id com params:', req.params);
  const { id } = req.params;
  db.query('DELETE FROM tarefa WHERE id = ?', [id], (err, results) => {
    if (err) {
      console.error('Erro ao deletar tarefa:', err);
      return res.status(500).json({ error: 'Erro ao deletar tarefa', details: err });
    }
    console.log('Tarefa deletada com sucesso:', results);
    res.send('Tarefa removida');
  });
});

app.listen(3000, () => console.log('Servidor rodando na porta 3000'));